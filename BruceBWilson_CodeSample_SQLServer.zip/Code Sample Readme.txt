Bruce B. Wilson
404-542-5552
bwilson@datastreamcons.com

Code Sample
07/02/2018

BruceBWilson_CodeSample_SQLServer.zip:

Stored Procedures and Functions written in Microsoft SQL Server 2014 T-SQL:
1. Text parsing stored procedures.
2. Date/Time conversion functions.
3. Numeric Base manipulation functions.
4. Energy conversion functions.
5. SubSystem to generate WPF UI output using meta-data from BMC Remedy ITSM.
6. Import Queueing/Processing Subsystem.
7. HTML-Report generating stored procedures.
8. Build Territory Dispatch Call-List by processing Company Org-Chart.

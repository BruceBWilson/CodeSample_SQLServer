﻿/*		  Name: f_WPF_ParseProperty
		Author: Bruce B. Wilson/Datastream Consulting, LLC. 404-542-5552
	   Created: 03/10/2015
   Called From: sp_WPF_GenerateXAML
   Description: Parse passed view-based display property collection for passed property tag and return 
				specified property value.  Property collections are stored in propShort column of the 
				field_dispprop table.

				\\gaatlenrmdy11q\c$\Program Files\BMC Software\ARSystem\Arserver\api\include\ar.h

				\\gaatlenfile04s\Remedy\Doc\Remedy764_SP3\Product Documentation
				BMC Remedy Action Request System 7.6.04 C API Reference.pdf

				Per Doug Mueller:
				The full mapping of all the metadata tables and their interrelationships and how all data 
				tables were created and named and all the syntax around these is contained in the Database 
				Reference manual.  You have to see what all tables are there and follow the keys to 
				related tables.  

				This Database Reference manual does not seem to have been moved to the on-line 
				documentation.  You could get a Database Reference manual from an older version and get 
				the model.

				The overall metadata model has not changed and any update to it is additive so a picture 
				from an older version is still accurate for the main forms and fields and interaction.
				Only new attributes or new constructs are missing.

    Parameters: @strPropShort
				@intTargetPropertyTag
				@intSubPropertyIndex
	   Returns: varchar(4000)
	  See Also: f_WPF_GenerateCSharp_Control
				f_WPF_GenerateXAML_Control
				f_WPF_GenerateXAML_PanelHolder
				f_WPF_GenerateXAML_Selection
				f_WPF_GenerateXAML_Table
				f_WPF_GenerateXAML_TextBox
				f_WPF_GenerateXAML_Trim
		  Test: 
				declare @strPropShort varchar(4000)
				select *
					from field_dispprop P
						inner join field F 
							on f.schemaId = P.schemaId and f.fieldId = P.fieldId
					where F.schemaId = 195			-- Signal Help Desk
						and P.vuiId = 536993375		-- Administrator
						and F.fieldname = 'tabTicket'

				set @strPropShort = '13\3\41\2\449\2200\110235\58400\4\6\1\5\6\2\7\40\2147483641\20\4\6\Ticket\21\41\2\0\0\130697818\100\24\0\65\41\2\0\0\0\0\66\41\2\0\0\137275918\48620793\143\40\0\151\41\2\0\0\0\100\170\40\902000006\246\2\1\'
/*
				when 0 then 0		-- AR_DATA_TYPE_NULL: No data value to consume
				when 4 then 1		-- AR_DATA_TYPE_CHAR: Number of characters\text.  See subsequent parsing below specific to this data type.
				when 6 then 1		-- AR_DATA_TYPE_ENUM
				when 8 then	1		-- AR_DATA_TYPE_BITMASK
				when 40 then 1		-- AR_DATA_TYPE_ULONG
				when 41 then 1		-- AR_DATA_TYPE_COORDS: Number of coordinates\x1\y1[\xn\yn...].  See subsequent parsing below specific to this data type.


13\
3\41\2\449\2200\110235\58400\
4\6\1\
5\6\2\
7\40\2147483641\
20\4\6\Ticket\
21\41\2\0\0\130697818\100\
24\0\
65\41\2\0\0\0\0\
66\41\2\0\0\137275918\48620793\
143\40\0\
151\41\2\0\0\0\100\
170\40\902000006\
246\2\1\

*/
				print dbo.f_WPF_ParseProperty(@strPropShort, 110, 2)	-- AR_DPROP_BUTTON_TEXT
				print dbo.f_WPF_ParseProperty(@strPropShort, 80, 2)		-- AR_DPROP_TEXT
				print dbo.f_WPF_ParseProperty(@strPropShort, 3, 0)		-- AR_DPROP_BBOX
				print dbo.f_WPF_ParseProperty(@strPropShort, 151, 0)	-- AR_DPROP_DATA_BBOX
				print dbo.f_WPF_ParseProperty(@strPropShort, 1, 1)		-- AR_DPROP_TRIM_TYPE
				print dbo.f_WPF_ParseProperty(@strPropShort, 143, 1)	-- AR_DPROP_TAB_ORDER
				print dbo.f_WPF_ParseProperty(@strPropShort, 4, 1)		-- AR_DPROP_VISIBLE
				print dbo.f_WPF_ParseProperty(@strPropShort, 64, 1)		-- AR_DPROP_DATA_RADIO
				print dbo.f_WPF_ParseProperty(@strPropShort, 170, 1)	-- AR_DPROP_DISPLAY_PARENT
*/

CREATE function [dbo].[f_WPF_ParseProperty](
	@strPropShort varchar(4000),
	@intTargetPropertyTag int,
	@intSubPropertyIndex int)
returns varchar(4000)
as
begin
	declare @strPropertyValue varchar(4000)
	declare @intNumItems int
	declare @intNumItem int
	declare @intPtr int
	declare @intPtrPropertyTag int
	declare @intPtrDataType int
	declare @intSlashPos int
	declare @intDataValues int
	declare @intCharacterCount int

	declare @strSubProperty1 varchar(4000)
	declare @strSubProperty2 varchar(4000)
	declare @strSubProperty3 varchar(4000)
	declare @strSubProperty4 varchar(4000)
	declare @strSubProperty5 varchar(4000)
	declare @strSubProperty6 varchar(4000)
	declare @strSubProperty7 varchar(4000)
	declare @strSubProperty8 varchar(4000)
	declare @strSubProperty9 varchar(4000)

	-- Property Collection Format: NumItems [, Property Tag, Data Type, Data Value(s)...]

	-- Capture number of items in property collection
	set @intSlashPos = charindex('\', @strPropShort)
	set @intNumItems = convert(int, substring(@strPropShort, 1, @intSlashPos - 1))
	set @intPtr = @intSlashPos + 1

	-- Iterate through propShort until property collection is exhausted or passed property tag is found
	set @intNumItem = 1
	set @intPtrPropertyTag = 0

	while @intNumItem <= @intNumItems and @intPtrPropertyTag <> @intTargetPropertyTag
	begin
		-- Capture property tag
		set @intSlashPos = charindex('\', @strPropShort, @intPtr)
		set @intPtrPropertyTag = convert(int, substring(@strPropShort, @intPtr, @intSlashPos - @intPtr))
		set @intPtr = @intSlashPos + 1

		-- Capture data type
		set @intSlashPos = charindex('\', @strPropShort, @intPtr)
		set @intPtrDataType = convert(int, substring(@strPropShort, @intPtr, @intSlashPos - @intPtr))
		set @intPtr = @intSlashPos + 1

		-- Determine number of data values to consume from propShort per data type
		set @intDataValues = 
			case @intPtrDataType
				when 0 then 0		-- AR_DATA_TYPE_NULL: No data value to consume
				when 2 then 1		-- AR_DATA_TYPE_INTEGER
				when 4 then 1		-- AR_DATA_TYPE_CHAR: Number of characters\text.  See subsequent parsing below specific to this data type.
				when 6 then 1		-- AR_DATA_TYPE_ENUM
				when 8 then	1		-- AR_DATA_TYPE_BITMASK
				when 40 then 1		-- AR_DATA_TYPE_ULONG
				when 41 then 1		-- AR_DATA_TYPE_COORDS: Number of coordinates\x1\y1[\xn\yn...].  See subsequent parsing below specific to this data type.
				else -1
			end

		if @intDataValues = -1		-- Unhandled data type
			break

		-- Consume determined number of data values from propShort
		if @intDataValues >= 1
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty1 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		-- Special parsing only for AR_DATA_TYPE_COORDS data type: Number of coordinates\x1\y1[\xn\yn...].
		-- Advance the number of data values to consume 2 X Number of coordinates.
		if @intPtrDataType = 41
		begin
			if convert(int, @strSubProperty1) = 0	-- If zero coordinates, advance past empty data
				set @intPtr = @intPtr + 1
			else
				set @intDataValues = 1 + convert(int, @strSubProperty1) * 2
		end

		if @intDataValues >= 2
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty2 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end
		
		if @intDataValues >= 3
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty3 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 4
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty4 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 5
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty5 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 6
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty6 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 7
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty7 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 8
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty8 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		if @intDataValues >= 9
		begin
			set @intSlashPos = charindex('\', @strPropShort, @intPtr)
			set @strSubProperty9 = substring(@strPropShort, @intPtr, @intSlashPos - @intPtr)
			set @intPtr = @intSlashPos + 1
		end

		-- Special parsing only for AR_DATA_TYPE_CHAR data type: Number of characters\text.
		-- Consume the number of characters specified in property one, ignoring \ delimiters.
		if @intPtrDataType = 4
		begin
			set @intCharacterCount = convert(int, @strSubProperty1)
			set @strSubProperty2 = substring(@strPropShort, @intPtr, @intCharacterCount)
			set @intPtr = @intPtr + @intCharacterCount + 1		-- Add 1 more to get past slash at end of text
		end

		if @intPtrPropertyTag = @intTargetPropertyTag
		begin
			if @intPtrDataType = 0				-- AR_DATA_TYPE_NULL: No data value to consume
				set @strPropertyValue = ''
			else if @intSubPropertyIndex = 0 and @intDataValues = 3		-- One set of coordinates
				set @strPropertyValue = @strSubProperty1 + '\' + @strSubProperty2 + '\' + @strSubProperty3
			else if @intSubPropertyIndex = 0 and @intDataValues = 5		-- Two set of coordinates
				set @strPropertyValue = @strSubProperty1 + '\' + @strSubProperty2 + '\' + @strSubProperty3 + '\' + @strSubProperty4 + '\' + @strSubProperty5
			else if @intSubPropertyIndex = 0 and @intDataValues = 9		-- Four set of coordinates
				set @strPropertyValue = @strSubProperty1 + '\' + @strSubProperty2 + '\' + @strSubProperty3 + '\' + @strSubProperty4 + '\' + @strSubProperty5 + '\' +
										@strSubProperty6 + '\' + @strSubProperty7 + '\' + @strSubProperty8 + '\' + @strSubProperty9
			else if @intSubPropertyIndex = 1
				set @strPropertyValue = @strSubProperty1
			else if @intSubPropertyIndex = 2
				set @strPropertyValue = @strSubProperty2
			else if @intSubPropertyIndex = 3
				set @strPropertyValue = @strSubProperty3
			else if @intSubPropertyIndex = 4
				set @strPropertyValue = @strSubProperty4
			else if @intSubPropertyIndex = 5
				set @strPropertyValue = @strSubProperty5
		end

		set @intNumItem = @intNumItem + 1
	end

	return(IsNull(@strPropertyValue, ''))
end
